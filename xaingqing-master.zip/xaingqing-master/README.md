# loveWall
微信小程序-表白墙

项目使用的**LeanCloud**作为后端云

###添加项目
1.下载源码

`git clone https://github.com/Anonlyy/loveWall.git`
            
        
2.打开微信web开发者工具,新建项目,添加**loveWall**源码

3.直接编译运行即可

###运行效果

[![loveWall.gif](https://i.loli.net/2017/09/11/59b5f51f69e2a.gif)](https://i.loli.net/2017/09/11/59b5f51f69e2a.gif)


