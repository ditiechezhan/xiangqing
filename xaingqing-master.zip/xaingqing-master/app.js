//app.js
import WeAppRedux from './redux/index.js';
import createStore from './redux/createStore.js';
import reducer from './store/reducer.js';

import ENVIRONMENT_CONFIG from './config/envConfig.js'
import PAGE_CONFIG from './config/pageConfig.js'

const { Provider } = WeAppRedux;
const store = createStore(reducer) // redux store
const AV = require('./libs/av-weapp-min.js');
App(
  Provider(store)(
    {
      globalData: {
        emitter: null,
        netcallController: null,
        ENVIRONMENT_CONFIG,
        PAGE_CONFIG,
        userInfo: null
      },
      onShow: function (e) {
        AV.init({
          appId: 'WiXg11L7e9Am54TGUTVdqawg-gzGzoHsz',
          appKey: 'osXv6BSAQzX8YLz9nmzUitbg',
        });
        if (e.scene == 1007 || e.scene == 1008) {
          try {
            this.globalData.netcall && this.globalData.netcall.destroy()
            this.globalData.nim && this.globalData.nim.destroy({
              done: function () {
              }
            })
          } catch (e) {
          }
        }
      },
      onLaunch: function (e) {
        var that = this
        //调用API从本地缓存中获取数据
        var logs = wx.getStorageSync('logs') || []
        logs.unshift(Date.now())
        wx.setStorageSync('logs', logs);
        let systemInfo = wx.getSystemInfoSync()
        this.globalData.videoContainerSize = {
          width: systemInfo.windowWidth,
          height: systemInfo.windowHeight
        }
        this.globalData.isPushBeCallPage = false
      }
    }
  )
);