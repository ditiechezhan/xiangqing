let PAGE_CONFIG = {}
PAGE_CONFIG.defaultUserLogo = '/images/default-icon.png' // 用户默认头像

module.exports = PAGE_CONFIG